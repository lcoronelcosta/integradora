<?php $__env->startSection("content"); ?>
<div>

<div class="col-sm-12">
    <div class="alert alert-success" style="display:none"></div>
         <div id="statistic-area">
            <?php
                $diaDeLaSemana = date("w", date('Y-m-d'));
                $dias = array('Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo');
                $firstday = "";
                $aux="";
                if ($diaDeLaSemana == 1){
                    $firstday = date('Y-m-d');      
                }
                else{
                    $firstday = date('Y-m-d', strtotime('last Monday'));
                }
                $g=0;$r=0;$p=0;
                for ($i=0; $i < 7; $i++) { 
                    ?>
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="font-size: 20px; text-align: center;"><?php echo e($dias[$i]); ?></div>
                    </div>
                        <div class="statistic-row row">
                            <!-- Recaudado -->
                            <div class="col-md-3 col-sm-6 col-xs-12">
                              <div class="info-box">
                                <span class="info-box-icon bg-green"><i class='ion ion-cash'></i></span>

                                <div class="info-box-content">
                                  <span class="info-box-text">RECAUDADO</span>
                                  <span class="info-box-number">
                                      <?php 
                                                    if($recaudado[$r]->fecha == $firstday){
                                                        echo $recaudado[$r]->valor;
                                                        $r++;

                                                    }else{echo "00.00";}
                                                ?>
                                  </span>
                                </div>
                              </div>
                            </div>

                            
                            <!-- Gastos -->
                             <div class="col-md-3 col-sm-6 col-xs-12">
                              <div class="info-box">
                                <span class="info-box-icon bg-red"><i class='ion ion-cash'></i></span>

                                <div class="info-box-content">
                                  <span class="info-box-text">GASTOS</span>
                                  <span class="info-box-number">
                                      <?php 
                                                    if($gastos[$g]->fecha == $firstday){
                                                        echo $gastos[$g]->valor;
                                                        $g++;

                                                    }else{echo "00.00";}
                                                ?>
                                  </span>
                                </div>
                              </div>
                            </div>


                            <!-- Prestado -->

                            <div class="col-md-3 col-sm-6 col-xs-12">
                              <div class="info-box">
                                <span class="info-box-icon bg-yellow"><i class='ion ion-cash'></i></span>

                                <div class="info-box-content">
                                  <span class="info-box-text">PRESTADO</span>
                                  <span class="info-box-number">
                                      <?php 
                                                    if($prestado[$p]->fecha == $firstday){
                                                        echo $prestado[$p]->valor;
                                                        $p++;

                                                    }else{echo "00.00";}
                                                    $firstday = date("Y-m-d",strtotime($firstday." + 1 days"));
                                                ?>
                                  </span>
                                </div>
                              </div>
                            </div>
                        
                        </div>
                    <?php
                }
            ?>

        </div>  
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("crudbooster::admin_template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>