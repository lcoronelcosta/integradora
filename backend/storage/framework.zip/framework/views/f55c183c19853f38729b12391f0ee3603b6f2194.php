<?php $__env->startSection("content"); ?>
<?php $i=0; ?>
<div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">
        jQuery(document).ready(function(){
            jQuery('#ajaxSubmit').click(function(e){
               e.preventDefault();
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                  }
              });
               jQuery.ajax({
                  url: "<?php echo e(url('/admin/refinancear')); ?>",
                  method: 'post',
                  data: {
                     id: jQuery('#id').text(),
                     totalt: jQuery('#totalt').text()
                  },
                  success: function(result){
                     
                  }});
               });
            });
    </script>

        <div class="panel panel-default">
            <div class="panel-heading">
                <strong><i class="fa fa-money"></i> 1</strong>
            </div>

            <div class="panel-body" style="padding:20px 0px 0px 0px">
            <?php echo Form::open(['route' => 'refinancear']); ?>

                <input type="hidden" name="id"  id="id" value="<?php echo e($row->id); ?>">
                <div class="box-body" id="parent-form-area">
                    <div class="table-responsive">
                        <table id="table-detail" class="table table-striped">
                            <tbody>
                                <tr>
                                    <td>Código</td>
                                    <td><?php echo e($row->codigo); ?></td>
                                </tr>
                                <tr>
                                    <td>Cliente</td>
                                    <td><?php echo e($row->nombres); ?></td>
                                </tr>
                                <tr>
                                    <td>Tasa Interes</td> 
                                    <td><?php echo e($row->interes); ?>%</td>
                                </tr>
                                <tr>
                                    <td>Interes del Prestamo</td> 
                                    <?php
                                        $tasa = (int)$row->interes;
                                        $int = ($tasa/100)*$row->monto;
                                    ?>
                                    <td>$<?php echo e($int); ?></td>
                                </tr>
                                <tr>
                                    <td>Dias Atrasados</td> 
                                    <?php
                                        $int = $row->interes/30;
                                        $fecha_actual = new DateTime("now");
                                        $fecha_pres = new DateTime($row->fecha_fin);
                                        $diff = $fecha_pres->diff($fecha_actual);
                                    ?>
                                    <td><?php echo e($diff->days); ?></td>
                                </tr>
                                <tr>
                                    <td>Total Atrasado</td>  
                                    <?php
                                        $totalt = round(($int*$diff->days),2);
                                    ?>
                                    <input type="hidden" name="totalt"  id="totalt" value="<?php echo e($totalt); ?>">
                                    <td name ="totalt">$<?php echo e($totalt); ?></td>
                                </tr>
                                <tr>
                                    <td>Forma Pago</td>
                                    <td><?php echo e($row->pago); ?></td>
                                </tr>
                                <tr>
                                    <td>Fecha</td>
                                    <td><?php echo e($row->fecha); ?></td>
                                </tr>
                                <tr>
                                    <td>Fecha Fin</td>
                                    <td><?php echo e($row->fecha_fin); ?></td>
                                </tr>
                                <tr>
                                    <td>Monto</td>
                                    <td><?php echo e($row->monto); ?></td>
                                </tr>
                                <tr>
                                    <td>Num Pagos</td>
                                    <td><?php echo e($row->num_pagos); ?></td>
                                </tr>
                                <tr>
                                    <td>Total a Pagar</td>
                                    <td><?php echo e($row->total_pagar); ?></td>
                                </tr>
                                <tr>
                                    <td>Saldo</td>
                                    <td><?php echo e($row->saldo); ?></td>
                                </tr>
                                <tr>
                                    <td>Saldo con Atraso</td>
                                    <?php
                                        $total = round((($int*$diff->days)+$row->saldo),2);
                                    ?>
                                    <td>$<?php echo e($total); ?></td>
                                </tr>
                                 <tr>
                                    <td>Estado</td>
                                    <td><?php echo e($row->estado); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>                                            
                </div><!-- /.box-body -->

                <div class="box-footer" style="background: #F5F5F5">

                        <div class="form-group">
                            <label class="control-label col-sm-2"></label>
                            <div class="col-sm-10">
                               <input type="submit" value="REFINANCEAR">
                            </div>
                        </div>


                    </div>

            <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("crudbooster::admin_template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>