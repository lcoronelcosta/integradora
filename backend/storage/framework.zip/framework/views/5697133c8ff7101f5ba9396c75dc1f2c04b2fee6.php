<?php echo e(!empty($value) ? date("F, d Y", strtotime($value)) : null); ?>

