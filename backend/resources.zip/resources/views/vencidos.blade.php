@extends("crudbooster::admin_template")
@section("content")

<div>

    <p><a title="Return" href="http://prueba.hierrodiseno.com/admin/sis_prestamo_vencidos"><i class="fa fa-chevron-circle-left "></i>&nbsp; Volver al listado PRESTAMOS VENCIDOS</a></p>
                    
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong><i class="fa fa-money"></i> 1</strong>
            </div>

            <div class="panel-body" style="padding:20px 0px 0px 0px">
            <form class="form-horizontal" method="post" id="form" enctype="multipart/form-data" action="http://127.0.0.1:8000/admin/sis_prestamo_vencidos/edit-save/34">
                <input type="hidden" name="_token" value="Fy04Sya8wCUB08IFfqS8dlVVWNNX1BDyFnVRlPEx">
                <input type="hidden" name="return_url" value="http://prueba.hierrodiseno.com/admin/sis_prestamo_vencidos">
                <input type="hidden" name="ref_mainpath" value="http://prueba.hierrodiseno.com/admin/sis_prestamo_vencidos">
                <input type="hidden" name="ref_parameter" value="return_url=http://prueba.hierrodiseno.com/admin/sis_prestamo_vencidos">
                <div class="box-body" id="parent-form-area">
                    <div class="table-responsive">
                        <table id="table-detail" class="table table-striped">
                            <tbody>
                                <tr>
                                    <td>Código</td>
                                    <td>{{$row->codigo}}</td>
                                </tr>
                                <tr>
                                    <td>Cliente</td>
                                    <td>{{$row->nombres}}</td>
                                </tr>
                                <tr>
                                    <td>Tasa Interes</td> 
                                    <td>{{$row->interes}}%</td>
                                </tr>
                                <tr>
                                    <td>Interes del Prestamo</td> 
                                    <?php
                                        $tasa = (int)$row->interes;
                                        $int = ($tasa/100)*$row->monto;
                                    ?>
                                    <td>${{$int}}</td>
                                </tr>
                                <tr>
                                    <td>Dias Atrasados</td> 
                                    <?php
                                        $int = $row->interes/$row->num_pagos;
                                        $fecha_actual = new DateTime("now");
                                        $fecha_pres = new DateTime($row->fecha_fin);
                                        $diff = $fecha_pres->diff($fecha_actual);
                                    ?>
                                    <td>{{$diff->days}}</td>
                                </tr>
                                <tr>
                                    <td>Total Atrasados</td>  
                                    <?php
                                        $total = round(($int*$diff->days),2);
                                    ?>
                                    <td>${{$total}}</td>
                                </tr>
                                <tr>
                                    <td>Forma Pago</td>
                                    <td>{{$row->pago}}</td>
                                </tr>
                                <tr>
                                    <td>Fecha</td>
                                    <td>{{$row->fecha}}</td>
                                </tr>
                                <tr>
                                    <td>Fecha Fin</td>
                                    <td>{{$row->fecha_fin}}</td>
                                </tr>
                                <tr>
                                    <td>Monto</td>
                                    <td>{{$row->monto}}</td>
                                </tr>
                                <tr>
                                    <td>Num Pagos</td>
                                    <td>{{$row->num_pagos}}</td>
                                </tr>
                                <tr>
                                    <td>Total a Pagar</td>
                                    <td>{{$row->total_pagar}}</td>
                                </tr>
                                <tr>
                                    <td>Saldo</td>
                                    <td>{{$row->saldo}}</td>
                                </tr>
                                <tr>
                                    <td>Saldo con Atraso</td>
                                    <?php
                                        $total = round((($int*$diff->days)+$row->saldo),2);
                                    ?>
                                    <td>${{$total}}</td>
                                </tr>
                                 <tr>
                                    <td>Estado</td>
                                    <td>{{$row->estado}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>                                            
                </div><!-- /.box-body -->

                <div class="box-footer" style="background: #F5F5F5">

                    <div class="form-group">
                        <label class="control-label col-sm-2"></label>
                        <div class="col-sm-10">
                        </div>
                    </div>


                </div><!-- /.box-footer-->

            </form>
            </div>
        </div>
    </div>
@endsection