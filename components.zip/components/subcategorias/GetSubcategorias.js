import React from 'react';
import { FlatList, ActivityIndicator, Text, View  } from 'react-native';
import { Button } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class GetSubcategorias extends React.Component {

  constructor(props){
    super(props);
    this.state ={ isLoading: true}
  }

  componentDidMount(){
    return fetch('http://hierrodiseno.com/mipedido/public/api/getsubcategorias')
      .then((response) => response.json())
      .then((responseJson) => {

        this.setState({
          isLoading: false,
          dataSource: responseJson.data,
        }, function(){
          console.error(responseJson.data);
        });

      })
      .catch((error) =>{
        console.error(error);
      });
  }



  render(){

    if(this.state.isLoading){
      return(
        <View style={{flex: 1, padding: 20}}>
          <ActivityIndicator/>
        </View>
      )
    }

    return(
      <View style={{flex: 1, paddingTop:20, alignItems: 'center', justifyContent: 'center',
    padding: 20, marginVertical: 8, marginHorizontal: 16}}>
        <FlatList
          data={this.state.dataSource}
          renderItem={({item}) => <Text>{item.nombre}, {item.is_destacada}</Text>}
          keyExtractor={({id}, index) => id}
        />
      </View>
    );
  }
}
